public class DynSequence {      
    private double[] array;

    public DynSequence(){
        array = new double[0];
    }

    public int size(){
        return array.length;
    }

    /* Aufgabe 2a */

}
